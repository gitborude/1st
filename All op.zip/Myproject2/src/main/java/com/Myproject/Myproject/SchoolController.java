package com.Myproject.Myproject;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SchoolController {

	@Autowired
	SessionFactory sf;
	ModelAndView mav = new ModelAndView("view");

	@RequestMapping("/")
	public ModelAndView home() {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Query query = ss.createQuery("from School");
		List<School> list = query.list();
		mav.addObject("msg", list);

		mav.setViewName("home");
		return mav;

	}

	@RequestMapping("save")
	public ModelAndView save(School school) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(school);
		tx.commit();

		mav.setViewName("home");
		return mav;
	}

	@RequestMapping("update")
	public ModelAndView update(School school) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.update(school);
		tx.commit();

		mav.setViewName("home");
		return mav;
	}

	@RequestMapping("delete")
	public ModelAndView delete(School school) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		School sc = ss.get(School.class, school.getId());
		ss.delete(sc);
		tx.commit();
		mav.setViewName("home");
		return mav;
	}

	@RequestMapping("alldata")
	public ModelAndView alldata() {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Query query = ss.createQuery("from School");
		List<School> list = query.list();
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", list);
		mav.setViewName("home");
		return mav;

	}
}
